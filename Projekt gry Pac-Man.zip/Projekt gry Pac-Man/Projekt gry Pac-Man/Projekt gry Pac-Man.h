﻿// Projekt gry Pac-Man.h: plik dołączany dla standardowych systemowych plików dołączanych,
// lub pliki dołączane specyficzne dla projektu.

#pragma once

#include <iostream>

// TODO: W tym miejscu przywołaj dodatkowe nagłówki wymagane przez program.
